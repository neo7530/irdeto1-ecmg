MultiDec-Irdeto Soft CAM plugin
--------------------------------
a MultiDec plugin to access crypted Irdeto 2 TV channels 
using a phoenix interface and your legal subscription smart card.
Betacrypt not supported. 


Known Issues
--------------
some times loses sync. normally reseting the card solves the problem. 
WatchTVPro not supported.  


HISTORY
----------
1.06  03-november-2004
 -Better compatibility with some providers like FullX.

1.05  09-march-2003
 -EMM support Added.
 -Block selected EMM Command. (edit ini file manully)
 -log EMMs send to the card. 
 -log Decrypted CWs. 
 
1.04
 -add irdeto1 and funcard support.

1.02
 -small bugfix.

1.01
 -first beta release.


===========================
best regards 
mrtoolate@hotmail.com

